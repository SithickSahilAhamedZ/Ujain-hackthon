export enum Page {
  Home = 'Home',
  Navigation = 'Navigation',
  Booking = 'Booking',
  Emergency = 'Emergency',
  Report = 'Report',
  Gallery = 'Gallery',
  Settings = 'Settings',
  About = 'About',
  Analytics = 'Analytics',
}
